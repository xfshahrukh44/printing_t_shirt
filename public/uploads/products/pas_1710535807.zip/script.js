function getPasswordStrength(password) {
    const minLength = 8;
    const hasUppercase = /[A-Z]/.test(password);
    const hasLowercase = /[a-z]/.test(password);
    const hasNumbers = /\d/.test(password);
    const hasSpecialChars = /[!@#$%^&*()_+]/.test(password);

    
    let strength = 0;

    if (password.length >= minLength) {
        strength++;
    }
    
    if (hasUppercase) {
        strength++;
    }
    
    if (hasLowercase) {
        strength++;
    }
    
    if (hasNumbers) {
        strength++;
    }
    
    if (hasSpecialChars) {
        strength++;
    }

    
    if (strength === 0) {
        return "Very Weak";
    } else if (strength === 1) {
        return "Weak";
    } else if (strength === 2) {
        return "Good";
    } else if (strength === 3) {
        return "Strong";
    } else {
        return "Very Strong";
    }
}

generatePassword = () => {
    let charset = "";

    if (document.getElementById('includeSpecial').checked) {
        charset += "!@#$%^&*()_+";
    }

    if (document.getElementById('includeNumbers').checked) {
        charset += "23456789";
    }

    if (document.getElementById('includeLowercase').checked) {
        charset += "abcdefghijklmnopqrstuvwxyz";
    }

    if (document.getElementById('includeUppercase').checked) {
        charset += "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    }

    let ambiguousChars = "(iIl1L| o0O `'-_\":;.,)";
    
    if (!document.getElementById('excludeAmbiguous').checked) {
        charset += ambiguousChars;
    } else {
        for (let i = 0; i < ambiguousChars.length; i++) {
            charset = charset.replace(ambiguousChars[i], '');
        }
    }

    if (!document.getElementById('excludeBrackets').checked) {
        charset += "[]{}|";
    } else {
        charset = charset.replace(/[(){}\[\]]/g, '');
    }

    let retVal = "";

    for (let i = 0, n = charset.length; i < document.getElementById('length').value; ++i) {
        retVal += charset.charAt(Math.floor(Math.random() * n));
    }

    
    const strength = getPasswordStrength(retVal);

    console.log(`Generated Password: ${retVal}`);
    console.log(`Password Strength: ${strength}`);

    return retVal;
}

function updatePassword() {
    const newPassword = generatePassword();
    document.getElementById('password').textContent = newPassword;
}

function startGenerating() {
    updatePassword();
    const intervalId = setInterval(updatePassword, 500);

    setTimeout(() => {
        clearInterval(intervalId);
    }, 5000);
}

document.querySelector('#length').addEventListener('change',  startGenerating);
document.querySelector('#includeSpecial').addEventListener('change',  startGenerating);
document.querySelector('#includeNumbers').addEventListener('change',  startGenerating);
document.querySelector('#includeLowercase').addEventListener('change',  startGenerating);
document.querySelector('#includeUppercase').addEventListener('change',  startGenerating);
document.querySelector('#excludeAmbiguous').addEventListener('change',  startGenerating);
document.querySelector('#excludeBrackets').addEventListener('change',  startGenerating);
